import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.Random;





public class rps {
	
	static int sel = 0;
	static String userName = System.getProperty("user.name");
	
	public static void main(String[] args) {
		JFrame mainframe = new JFrame("Main");
		JFrame helpFrame = new JFrame("Help");
		JFrame playFrame = new JFrame("Play");
		mainframe.setResizable(false);
		mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.getContentPane().setLayout(new BorderLayout());
		
		JPanel panel = new JPanel();
        JPanel imagePanel = new JPanel(); // Changed the name to avoid naming conflicts
        JPanel buttons = new JPanel();
        

        imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.X_AXIS));
        mainframe.add(panel, BorderLayout.NORTH);
        mainframe.add(imagePanel, BorderLayout.CENTER); // Added imagePanel instead of image
        mainframe.add(buttons, BorderLayout.SOUTH);
        
        

		JLabel intro = new JLabel("Welcome to Kierans rock paper scissors!");
		JButton exit = new JButton("Exit");
		JButton play = new JButton("Play");
		JButton help = new JButton("Help");
		panel.add(intro);
		buttons.add(play);
		buttons.add(exit);
		buttons.add(help);

		JLabel image = new JLabel();
        ImageIcon icon = new ImageIcon("C:\\\\Users\\\\" + userName +"\\\\Downloads\\\\RPS\\\\Images\\\\Icons.png");
        image.setIcon(icon);
        imagePanel.add(Box.createHorizontalGlue());
        imagePanel.add(image);
        imagePanel.add(Box.createHorizontalGlue());
		
		
		help.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	mainframe.setVisible(false);
                helpFrame.setVisible(true);
                helpFrame.setResizable(false);
        		helpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        		helpFrame.getContentPane().setLayout(new BorderLayout());
        		helpFrame.setSize(550,350);
        		
        		JPanel panel = new JPanel();
        		JPanel buttons = new JPanel();
        		helpFrame.getContentPane().add(panel);
        		helpFrame.getContentPane().add(buttons, BorderLayout.SOUTH);
        		
        		JButton back = new JButton("Back");
        		JButton exit = new JButton("Exit");
        		JLabel title = new JLabel("Help Menu");
        		JLabel diagram = new JLabel("");
        		ImageIcon icon = new ImageIcon("C:\\\\Users\\\\" + userName + "\\\\Downloads\\\\RPS\\\\Images\\\\diagram.png");
        		Image image = icon.getImage(); // transform it 
        		Image newimg = image.getScaledInstance(510, 252,  java.awt.Image.SCALE_SMOOTH);
        		ImageIcon ne = new ImageIcon(newimg);
        		diagram.setIcon(ne);
        		//https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon
        		
        		JLabel exp = new JLabel();
        		
        		
        		
        		title.setFont(new Font("Arial", Font.BOLD, 18));
        		panel.add(diagram);
        		panel.add(exp);
        		helpFrame.getContentPane().add(title, BorderLayout.NORTH);
        		buttons.add(back);
        		buttons.add(exit);
        		
        		back.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        helpFrame.setVisible(false);
                        mainframe.setVisible(true);
                    }
                });
        		
        		exit.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                });
            }
        });
		
		play.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	playFrame.setVisible(true);
            	mainframe.setVisible(false);
            	playFrame.setResizable(false);
            	playFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            	playFrame.getContentPane().setLayout(new BorderLayout());
            	playFrame.setSize(650,350);
            	
            	JPanel panel = new JPanel();
            	JPanel buttons = new JPanel();
            	JPanel buttontwo = new JPanel();
            	JPanel bot = new JPanel();
            	buttons.setLayout(null);
            	panel.setLayout(null);
            	
            	
            	
            	playFrame.add(panel, BorderLayout.CENTER);
            	playFrame.add(buttons);
            	playFrame.add(buttontwo, BorderLayout.SOUTH);
            	playFrame.add(bot, BorderLayout.EAST);
            	
            	JButton Scissors = new JButton("Scissors");
            	JButton Rock = new JButton("Rock");
            	JButton Paper = new JButton("Paper");
            	JButton back = new JButton("Back");
            	JButton exit = new JButton("Exit");
            	JButton botact = new JButton("Bot Output");
            	
            	JLabel rockimg = new JLabel();
            	JLabel paperimg = new JLabel();
            	JLabel scimg = new JLabel();
            	JLabel botout = new JLabel();
            	JLabel playersel = new JLabel();
            	JLabel output = new JLabel();
            	
            	
            	ImageIcon rock = new ImageIcon("C:\\\\Users\\\\" + userName + "\\\\Downloads\\\\RPS\\\\Images\\\\Rock.png");
            	ImageIcon paper = new ImageIcon("C:\\\\Users\\\\" + userName + "\\\\Downloads\\\\RPS\\\\Images\\\\Paper.png");
            	ImageIcon scissors = new ImageIcon("C:\\\\Users\\\\" + userName + "\\\\Downloads\\\\RPS\\\\Images\\\\Scissors.png");
            	ImageIcon blank = new ImageIcon("C:\\\\Users\\\\" + userName + "\\\\Downloads\\\\RPS\\\\Images\\\\blank.png");

            	
            	
            	
            	Image imageone = rock.getImage(); // transform it 
        		Image imgone = imageone.getScaledInstance(126, 225,  java.awt.Image.SCALE_SMOOTH);
        		ImageIcon ne2 = new ImageIcon(imgone);
        		
        		Image imagetwo = paper.getImage(); // transform it 
        		Image imgtwo = imagetwo.getScaledInstance(126, 225,  java.awt.Image.SCALE_SMOOTH);
        		ImageIcon ne3 = new ImageIcon(imgtwo);
        		
        		Image imagethree = scissors.getImage(); // transform it 
        		Image imgthree = imagethree.getScaledInstance(126, 225,  java.awt.Image.SCALE_SMOOTH);
        		ImageIcon ne4 = new ImageIcon(imgthree);
        		
        		Image blankimage = blank.getImage(); // transform it 
        		Image blancimage = blankimage.getScaledInstance(126, 225,  java.awt.Image.SCALE_SMOOTH);
        		ImageIcon ne5 = new ImageIcon(blancimage);
        		
        		rockimg.setIcon(ne2);
        		paperimg.setIcon(ne3);
        		scimg.setIcon(ne4);
        		
        		
        		
        		playersel.setIcon(ne5);
        		botout.setIcon(ne5);
        		
        		
        		panel.add(rockimg);
        		panel.add(paperimg);
        		panel.add(scimg);
            	
            	Scissors.setBounds(25, 50, 100, 30);
            	Rock.setBounds(25, 100, 100, 30);
            	Paper.setBounds(25, 150, 100, 30);
            	botact.setBounds(25, 240, 100, 30);
            	rockimg.setBounds(400, 150, 0, 0);
            	paperimg.setBounds(600, 150, 0,0);
            	
            	buttons.add(Scissors);
            	buttons.add(Rock);
            	buttons.add(Paper);
            	buttons.add(botact);
            	bot.add(playersel);
            	buttontwo.add(back);
            	buttontwo.add(exit);
            	buttontwo.add(output);
            	bot.add(botout);
            	
            	
            	
            	
            	
            	
            	Scissors.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                    	sel = 3;
                    	playersel.setIcon(ne4);
                    	
                    }
                });
            	
            	Rock.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                    	sel = 1;
                    	playersel.setIcon(ne2);
                    	
                    }
                });
            	
            	Paper.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                    	sel = 2;
                    	playersel.setIcon(ne3);
                    	
                    }
                });
            	
                
            
            	
            	
            	botact.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                    	
                    	int randomNumber = new Random().nextInt(3) + 1;

                		if(randomNumber == 1) {
                			botout.setIcon(ne2);
                		}else if (randomNumber == 2) {
                			botout.setIcon(ne3);
                		}else if (randomNumber == 3) {
                			botout.setIcon(ne4);
                		}
                		
                		
                		if(sel == randomNumber) {
            				output.setText("Its a tie!");
            			}
            		
            			//checking for all other moves possible
            		
            			else if(sel == 1) {
            			
            				if(randomNumber == 2) {
            					output.setText("Computer Won");
            				} 
            				else if(randomNumber == 3) {
            					output.setText("You won!");
            				}
            			}
            		
            			else if(sel == 2) {
            			
            				if(randomNumber == 1) {
            					output.setText("You won!");
            				} 
            				else if(randomNumber == 3) {
            					output.setText("Computer Won!");
            				}
            			}
            		
            			else if(sel == 3) {
            			
            				if(randomNumber == 2) {
            					output.setText("You won!");
            				} 
            				else if(randomNumber == 1) {
            					output.setText("Computer Won!");
            				}
            			}
                		randomNumber = 0;
                    }
                });
            	
            	
            	back.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        playFrame.setVisible(false);
                        mainframe.setVisible(true);
                    }
                });
            	
            	exit.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                });
            	
            	
            	
            }
        });
		
		exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
		
		mainframe.pack();
        mainframe.setSize(600,350);
        mainframe.setVisible(true);
	}
	
}